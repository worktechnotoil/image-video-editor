import React from 'react';
import type { MediaItem, MusicTrack } from '../types';
export interface VideoEditorProps {
    onClose?: () => void;
    onFinishExport?: (editedMedia: Record<string, MediaItem>, paths: string[], editedArray: MediaItem[], cameraMode?: string) => void;
    headerTitle?: string;
    customCancelIcon?: React.ReactNode;
    onCancelPress?: () => void;
    cameraModes?: string[];
    defaultCameraMode?: string;
    musicList?: MusicTrack[];
}
export default function VideoEditor({ onClose, onFinishExport, headerTitle, customCancelIcon, onCancelPress, cameraModes, defaultCameraMode, musicList, }: VideoEditorProps): React.JSX.Element;
