import type { FrameCaptureOptions } from '../types';
export declare function captureFrame(uri: string, options: FrameCaptureOptions): Promise<string>;
