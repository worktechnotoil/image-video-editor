export declare function playVideo(uri: string): Promise<boolean>;
