import React from 'react';
import { ViewStyle, StyleProp } from 'react-native';
type Props = {
    uri: string;
    paused?: boolean;
    muted?: boolean;
    style?: StyleProp<ViewStyle>;
    resizeMode?: string;
    trimStartMs?: number;
    trimEndMs?: number;
    seekToMs?: number;
    onChange?: (e: {
        nativeEvent: {
            currentTimeMs: number;
        };
    }) => void;
};
export declare function VideoPreview(props: Props): React.JSX.Element;
export {};
