import React from 'react';
import { ViewStyle } from 'react-native';
export interface CameraViewRef {
    capturePhoto(): Promise<{
        uri: string;
        width: number;
        height: number;
    }>;
    startRecording(): Promise<void>;
    stopRecording(): Promise<{
        uri: string;
        durationMs: number;
        width: number;
        height: number;
    }>;
}
interface Props {
    facing: 'front' | 'back';
    flashMode?: 'on' | 'off';
    style?: ViewStyle;
}
export declare const CameraView: React.ForwardRefExoticComponent<Props & React.RefAttributes<CameraViewRef>>;
export {};
