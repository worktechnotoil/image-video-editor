import type { ImageEditOptions, VideoTrimOptions } from '../types';
export declare function editImage(uri: string, options: ImageEditOptions): Promise<string>;
export declare function trimVideo(uri: string, options: VideoTrimOptions): Promise<string>;
