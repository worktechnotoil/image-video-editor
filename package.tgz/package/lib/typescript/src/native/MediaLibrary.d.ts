import type { MediaItem, MediaType } from '../types';
export type Album = {
    id: string;
    title: string;
};
export type MediaQuery = {
    limit?: number;
    offset?: number;
    type?: MediaType | 'all';
    albumId?: string;
};
export declare function requestMediaAccess(): Promise<boolean>;
export declare function listAlbums(): Promise<Album[]>;
export declare function listMedia(query: MediaQuery): Promise<MediaItem[]>;
export declare function exportAsset(localId: string): Promise<string>;
export declare function saveToGallery(uri: string, type: string): Promise<boolean>;
