import type { MediaItem } from '../types';
export declare function pickMedia(): Promise<MediaItem[]>;
