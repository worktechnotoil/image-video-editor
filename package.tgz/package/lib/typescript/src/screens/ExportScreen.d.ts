import React from 'react';
import type { MediaItem } from '../types';
interface ExportScreenProps {
    editedMedia: Record<string, MediaItem>;
    onHome: () => void;
    onReEdit: (item: MediaItem) => void;
}
export declare function ExportScreen({ editedMedia, onHome, onReEdit }: ExportScreenProps): React.JSX.Element;
export {};
