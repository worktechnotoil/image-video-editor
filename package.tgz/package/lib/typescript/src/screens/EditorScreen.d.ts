import React from 'react';
import type { MediaItem, MusicTrack } from '../types';
export declare function EditorScreen({ items, initialIndex, onBack, onSaved, onOpenCrop, musicList, }: {
    items: MediaItem[];
    initialIndex?: number;
    onBack: () => void;
    onSaved: (updatedItems: MediaItem[]) => void;
    onOpenCrop: (item: MediaItem) => void;
    musicList?: MusicTrack[];
}): React.JSX.Element;
