import React from 'react';
import type { MediaItem } from '../types';
interface CropScreenProps {
    item: MediaItem;
    onBack: () => void;
    onSave: (uri: string, thumb?: string, duration?: number) => void;
}
export declare function CropScreen({ item, onBack, onSave }: CropScreenProps): React.JSX.Element;
export {};
