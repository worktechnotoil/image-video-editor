import React from 'react';
import type { MediaItem } from '../types';
export declare function GalleryScreen({ items, onBack, onSelect, onNext, }: {
    items: MediaItem[];
    onBack: () => void;
    onSelect: (item: MediaItem) => void;
    onNext: () => void;
}): React.JSX.Element;
