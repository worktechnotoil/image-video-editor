import React from 'react';
import type { MediaItem } from '../types';
export declare function PickScreen({ items, onPicked, onNext, headerTitle, customCancelIcon, onCancelPress, cameraModes, onCameraModeChange, defaultCameraMode, }: {
    items: MediaItem[];
    onPicked: (items: MediaItem[]) => void;
    onNext: (picked: MediaItem[]) => void;
    headerTitle?: string;
    customCancelIcon?: React.ReactNode;
    onCancelPress?: () => void;
    cameraModes?: string[];
    onCameraModeChange?: (mode: string) => void;
    defaultCameraMode?: string;
}): React.JSX.Element;
